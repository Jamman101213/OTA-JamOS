import json
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import urllib.parse
import urllib.request
import webbrowser
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

APP_NAME = "JamOS"
VERSION = "0.04"
WINDOW_W = 420
WINDOW_H = 800
REPO_API = "https://api.github.com/repos/Jamman101213/OTA-JamOS/contents"
PREFERRED_OTA_PATHS = ["direct", ""]

ROOT = Path(__file__).resolve().parent
USERDATA = ROOT / "userdata" / "userdata.json"
SYSTEM = ROOT / "system"
APPS_DIR = ROOT / "apps"


def ensure_dirs():
    for p in [ROOT / "userdata", SYSTEM, APPS_DIR]:
        p.mkdir(parents=True, exist_ok=True)


def load_userdata():
    ensure_dirs()
    data = {"os_version": VERSION, "theme": "dark", "accent": "purple", "notes": ""}
    try:
        if USERDATA.exists():
            raw = json.loads(USERDATA.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                data.update(raw)
    except Exception:
        pass
    return data


def save_userdata(data):
    ensure_dirs()
    USERDATA.write_text(json.dumps(data, indent=2), encoding="utf-8")


def version_tuple(v):
    nums = []
    for part in str(v).strip().split('.'):
        try:
            nums.append(int(part))
        except ValueError:
            nums.append(0)
    return tuple(nums)


def github_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "JamOS"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def discover_ota():
    candidates = []
    seen = set()
    errors = []
    for base in PREFERRED_OTA_PATHS:
        url = REPO_API + ("/" + base if base else "")
        try:
            items = github_json(url)
            if isinstance(items, dict) and items.get("message"):
                continue
            for item in items:
                if item.get("type") == "file" and item.get("name", "").lower().endswith(".zip"):
                    name = item["name"]
                    stem = name[:-4]
                    if not stem or not stem[0].isdigit():
                        continue
                    try:
                        vt = version_tuple(stem)
                    except Exception:
                        continue
                    if name in seen:
                        continue
                    seen.add(name)
                    candidates.append({"version": stem, "name": name, "url": item.get("download_url"), "path": item.get("path")})
        except Exception as e:
            errors.append(str(e))
    if not candidates:
        return None, errors
    candidates.sort(key=lambda x: version_tuple(x["version"]), reverse=True)
    return candidates[0], errors


def safe_extract_zip(zip_path, dest):
    with zipfile.ZipFile(zip_path) as z:
        infos = z.infolist()
        root_names = [Path(i.filename).parts for i in infos if i.filename and not i.is_dir()]
        top = set(parts[0] for parts in root_names if parts)
        strip = len(top) == 1 and next(iter(top)) not in {"setup.txt"} and not any(Path(i.filename).name == "setup.txt" and len(Path(i.filename).parts) == 1 for i in infos)
        with tempfile.TemporaryDirectory(dir=dest) as td:
            td = Path(td)
            for i in infos:
                rel = Path(i.filename)
                if strip:
                    rel = Path(*rel.parts[1:]) if len(rel.parts) > 1 else Path(rel.name)
                if str(rel) in {"", "."}:
                    continue
                target = td / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                if i.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    with z.open(i) as src, open(target, "wb") as out:
                        shutil.copyfileobj(src, out)
            setup = td / "setup.txt"
            if not setup.exists():
                raise ValueError("The OTA ZIP is missing setup.txt at its root.")
            manifest = parse_manifest(setup)
            return td, manifest


def parse_manifest(setup_path):
    manifest = {"version": None, "userdata_version": None, "files": []}
    for raw in setup_path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.strip()
        if k == "file":
            manifest["files"].append(v.replace('\\', '/').lstrip('/'))
        elif k in manifest:
            manifest[k] = v
    if not manifest["version"] or not manifest["files"]:
        raise ValueError("setup.txt is invalid or incomplete.")
    return manifest


def install_from_staging(staging, manifest):
    expected = set()
    for rel in manifest["files"]:
        relp = Path(rel)
        if relp.name == ".gitkeep":
            relp.parent.mkdir(parents=True, exist_ok=True)
            continue
        expected.add(relp.as_posix())
        src = staging / relp
        if not src.exists() or not src.is_file():
            raise ValueError(f"OTA package is missing: {rel}")

    backup = ROOT / ".ota_backup"
    if backup.exists():
        shutil.rmtree(backup, ignore_errors=True)
    backup.mkdir(parents=True, exist_ok=True)

    # Preserve the running updater/launcher and user data unless the manifest explicitly contains them.
    managed_roots = {"main.py", "run.bat", "run.sh", "requirements.txt", "web", "system", "apps"}
    for child in list(ROOT.iterdir()):
        rel = child.relative_to(ROOT).as_posix()
        if rel.startswith("userdata/") or rel == "userdata":
            continue
        if child.name == ".ota_backup":
            continue
        in_scope = child.name in managed_roots or child.is_file()
        if in_scope and rel not in expected and child.name != "setup.txt":
            dest = backup / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.move(str(child), str(dest))
            except Exception:
                if child.is_dir():
                    shutil.rmtree(child, ignore_errors=True)
                else:
                    child.unlink(missing_ok=True)

    for rel in expected:
        src = staging / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    data = load_userdata()
    data["os_version"] = manifest.get("userdata_version") or manifest["version"]
    save_userdata(data)
    (ROOT / "setup.txt").unlink(missing_ok=True)
    shutil.rmtree(backup, ignore_errors=True)


class JamOS(tk.Tk):
    def __init__(self):
        super().__init__()
        ensure_dirs()
        self.userdata = load_userdata()
        self.title("JamOS")
        self.geometry(f"{WINDOW_W}x{WINDOW_H}")
        self.minsize(WINDOW_W, WINDOW_H)
        self.maxsize(WINDOW_W, WINDOW_H)
        self.resizable(False, False)
        self.configure(bg="#111318")
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.option_add("*Font", ("Segoe UI", 10))
        self._style()
        self._build()
        self.show_home()

    def _style(self):
        s = ttk.Style(self)
        try: s.theme_use("vista")
        except Exception: pass
        s.configure("TFrame", background="#111318")
        s.configure("Card.TFrame", background="#181b21")
        s.configure("TLabel", background="#111318", foreground="#e8eaf0")
        s.configure("Title.TLabel", background="#111318", foreground="#ffffff", font=("Segoe UI Semibold", 22))
        s.configure("Sub.TLabel", background="#111318", foreground="#9da3b0", font=("Segoe UI", 9))
        s.configure("Card.TLabel", background="#181b21", foreground="#e8eaf0")
        s.configure("Accent.TButton", font=("Segoe UI Semibold", 10), padding=(12, 10))
        s.map("Accent.TButton", foreground=[("active", "#ffffff")])

    def _build(self):
        self.header = ttk.Frame(self)
        self.header.pack(fill="x", padx=18, pady=(16, 8))
        self.title_var = tk.StringVar(value="Home")
        ttk.Label(self.header, textvariable=self.title_var, style="Title.TLabel").pack(side="left")
        ttk.Label(self.header, text=f"{self.userdata.get('os_version', VERSION)}", style="Sub.TLabel").pack(side="right", pady=(10,0))

        self.body = ttk.Frame(self)
        self.body.pack(fill="both", expand=True, padx=18)

        self.nav = tk.Frame(self, bg="#181b21", height=68)
        self.nav.pack(fill="x", side="bottom")
        buttons = [("⌂", "Home", self.show_home), ("▦", "Apps", self.show_apps), ("⚙", "Settings", self.show_settings)]
        for glyph, label, fn in buttons:
            b = tk.Button(self.nav, text=f"{glyph}\n{label}", command=fn, bg="#181b21", fg="#bfc4cf", activebackground="#22262e", activeforeground="#ffffff", relief="flat", borderwidth=0, font=("Segoe UI", 9), width=11, height=3)
            b.pack(side="left", expand=True)

    def clear_body(self):
        for w in self.body.winfo_children(): w.destroy()

    def show_home(self):
        self.title_var.set("Home")
        self.clear_body()
        card = tk.Frame(self.body, bg="#181b21")
        card.pack(fill="x", pady=(8, 14))
        tk.Label(card, text="JamOS", bg="#181b21", fg="#ffffff", font=("Segoe UI Semibold", 26)).pack(anchor="w", padx=18, pady=(18, 2))
        tk.Label(card, text="A small desktop OS built in Python.", bg="#181b21", fg="#9da3b0", font=("Segoe UI", 10)).pack(anchor="w", padx=18, pady=(0, 18))
        q = tk.Label(self.body, text="Quick apps", bg="#111318", fg="#ffffff", font=("Segoe UI Semibold", 14))
        q.pack(anchor="w", pady=(0, 8))
        grid = tk.Frame(self.body, bg="#111318")
        grid.pack(fill="x")
        apps = [("▣", "Browser", self.browser), ("✎", "Notes", self.notes), ("+", "Calculator", self.calculator), ("□", "Files", self.files), ("◷", "Calendar", self.calendar), ("↻", "Updates", self.updates)]
        for i, (icon, name, fn) in enumerate(apps):
            r, c = divmod(i, 2)
            b = tk.Button(grid, text=f"{icon}  {name}", command=fn, anchor="w", bg="#181b21", fg="#e8eaf0", activebackground="#232731", activeforeground="#ffffff", relief="flat", padx=16, pady=16, font=("Segoe UI Semibold", 10))
            b.grid(row=r, column=c, sticky="ew", padx=4, pady=4)
        grid.columnconfigure(0, weight=1); grid.columnconfigure(1, weight=1)
        status = tk.Frame(self.body, bg="#181b21")
        status.pack(fill="x", pady=14)
        tk.Label(status, text="System", bg="#181b21", fg="#ffffff", font=("Segoe UI Semibold", 11)).pack(anchor="w", padx=14, pady=(12,4))
        tk.Label(status, text=f"OS version  {self.userdata.get('os_version', VERSION)}\nUpdates are available from your GitHub OTA channel.", justify="left", bg="#181b21", fg="#9da3b0", font=("Segoe UI", 9)).pack(anchor="w", padx=14, pady=(0,12))

    def show_apps(self):
        self.title_var.set("Apps")
        self.clear_body()
        apps = [
            ("Browser", "Open websites and search the web", self.browser),
            ("Notes", "Simple local notes", self.notes),
            ("Calculator", "Basic calculator", self.calculator),
            ("Calendar", "Monthly calendar", self.calendar),
            ("Files", "Open the JamOS folder", self.files),
            ("Updates", "Check GitHub for OS updates", self.updates),
            ("Settings", "Configure JamOS", self.show_settings),
            ("About", "Version and system information", self.about),
        ]
        for name, desc, fn in apps:
            row = tk.Frame(self.body, bg="#181b21")
            row.pack(fill="x", pady=4)
            tk.Label(row, text=name, bg="#181b21", fg="#ffffff", font=("Segoe UI Semibold", 11)).pack(anchor="w", padx=14, pady=(12,0))
            tk.Label(row, text=desc, bg="#181b21", fg="#9da3b0", font=("Segoe UI", 9)).pack(anchor="w", padx=14, pady=(2,4))
            tk.Button(row, text="Open", command=fn, bg="#272b34", fg="#ffffff", activebackground="#353b47", relief="flat", padx=12, pady=7).pack(anchor="e", padx=12, pady=(0,12))

    def show_settings(self):
        self.title_var.set("Settings")
        self.clear_body()
        tk.Label(self.body, text="Appearance", bg="#111318", fg="#ffffff", font=("Segoe UI Semibold", 14)).pack(anchor="w", pady=(6, 8))
        theme = tk.StringVar(value=self.userdata.get("theme", "dark"))
        frame = tk.Frame(self.body, bg="#181b21")
        frame.pack(fill="x", pady=4)
        tk.Label(frame, text="Theme", bg="#181b21", fg="#ffffff").pack(side="left", padx=14, pady=14)
        cb = ttk.Combobox(frame, values=["dark"], textvariable=theme, state="readonly", width=12)
        cb.pack(side="right", padx=14)
        tk.Label(self.body, text="System", bg="#111318", fg="#ffffff", font=("Segoe UI Semibold", 14)).pack(anchor="w", pady=(18, 8))
        info = tk.Frame(self.body, bg="#181b21")
        info.pack(fill="x", pady=4)
        tk.Label(info, text=f"Installed version\n{self.userdata.get('os_version', VERSION)}", justify="left", bg="#181b21", fg="#b8beca").pack(anchor="w", padx=14, pady=14)
        tk.Button(self.body, text="Check for OTA updates", command=self.updates, bg="#5b38c7", fg="#ffffff", activebackground="#6845d7", relief="flat", pady=10).pack(fill="x", pady=12)
        tk.Button(self.body, text="About JamOS", command=self.about, bg="#272b34", fg="#ffffff", activebackground="#353b47", relief="flat", pady=10).pack(fill="x")

    def popup(self, title, w=520, h=420):
        win = tk.Toplevel(self)
        win.title(title)
        win.geometry(f"{w}x{h}")
        win.configure(bg="#111318")
        win.resizable(False, False)
        return win

    def browser(self):
        win = self.popup("JamOS Browser", 700, 560)
        top = tk.Frame(win, bg="#181b21", padx=10, pady=10); top.pack(fill="x")
        entry = tk.Entry(top, bg="#101217", fg="#ffffff", insertbackground="#ffffff", relief="flat", font=("Segoe UI", 11))
        entry.pack(side="left", fill="x", expand=True, padx=(0,8), ipady=8)
        entry.insert(0, "https://www.google.com")
        def go():
            url = entry.get().strip()
            if not url: return
            if "://" not in url: url = "https://www.google.com/search?q=" + urllib.parse.quote(url)
            webbrowser.open(url)
        tk.Button(top, text="Open", command=go, bg="#5b38c7", fg="#ffffff", relief="flat", padx=14, pady=8).pack(side="right")
        tk.Label(win, text="JamOS Browser uses your normal Windows browser for web pages. This keeps the OS lightweight and stable.", bg="#111318", fg="#9da3b0", wraplength=650, justify="left").pack(anchor="w", padx=16, pady=16)

    def notes(self):
        win = self.popup("Notes", 560, 520)
        text = tk.Text(win, bg="#101217", fg="#f0f1f4", insertbackground="#ffffff", relief="flat", wrap="word", padx=12, pady=12)
        text.pack(fill="both", expand=True, padx=12, pady=12)
        text.insert("1.0", self.userdata.get("notes", ""))
        def save():
            self.userdata["notes"] = text.get("1.0", "end-1c")
            save_userdata(self.userdata)
            messagebox.showinfo("Notes", "Saved locally.", parent=win)
        tk.Button(win, text="Save", command=save, bg="#5b38c7", fg="#ffffff", relief="flat", padx=18, pady=8).pack(anchor="e", padx=12, pady=(0,12))

    def calculator(self):
        win = self.popup("Calculator", 360, 500)
        expr = tk.StringVar()
        display = tk.Entry(win, textvariable=expr, justify="right", bg="#101217", fg="#ffffff", relief="flat", font=("Consolas", 20))
        display.pack(fill="x", padx=12, pady=12, ipady=12)
        grid = tk.Frame(win, bg="#111318"); grid.pack(fill="both", expand=True, padx=8, pady=8)
        keys = ["7","8","9","/","4","5","6","*","1","2","3","-","0",".","=","+"]
        def press(k):
            if k == "=":
                try: expr.set(str(eval(expr.get(), {"__builtins__": {}}, {})))
                except Exception: expr.set("Error")
            else: expr.set(expr.get() + k)
        for i,k in enumerate(keys):
            r,c=divmod(i,4)
            tk.Button(grid,text=k,command=lambda k=k:press(k),bg="#181b21",fg="#ffffff",activebackground="#272c35",relief="flat",font=("Segoe UI",12)).grid(row=r,column=c,sticky="nsew",padx=3,pady=3)
        for i in range(4): grid.columnconfigure(i, weight=1)
        for i in range(4): grid.rowconfigure(i, weight=1)

    def files(self):
        os.startfile(str(ROOT)) if os.name == "nt" else subprocess.Popen(["xdg-open", str(ROOT)])

    def calendar(self):
        win = self.popup("Calendar", 420, 360)
        import calendar as cal
        import datetime
        now=datetime.date.today()
        txt=cal.month(now.year, now.month)
        tk.Label(win,text=txt,justify="left",font=("Consolas",14),bg="#111318",fg="#ffffff").pack(padx=20,pady=20)

    def about(self):
        messagebox.showinfo("About JamOS", f"JamOS\nVersion {self.userdata.get('os_version', VERSION)}\n\nNative Tkinter desktop shell\nOTA channel: GitHub / direct", parent=self)

    def updates(self):
        win = self.popup("JamOS Updates", 560, 430)
        status = tk.StringVar(value="Ready to check for updates.")
        tk.Label(win,text="Software Updates",bg="#111318",fg="#ffffff",font=("Segoe UI Semibold",16)).pack(anchor="w",padx=18,pady=(18,4))
        tk.Label(win,textvariable=status,bg="#111318",fg="#9da3b0",wraplength=500,justify="left").pack(anchor="w",padx=18,pady=(0,12))
        bar=ttk.Progressbar(win,mode="determinate",maximum=100); bar.pack(fill="x",padx=18,pady=8)
        download_btn=tk.Button(win,text="Check for Updates",bg="#5b38c7",fg="#ffffff",relief="flat",padx=16,pady=10)
        download_btn.pack(pady=10)
        install_btn=tk.Button(win,text="Install & Restart",bg="#2b3039",fg="#ffffff",relief="flat",padx=16,pady=10,state="disabled")
        install_btn.pack(pady=4)
        state={"candidate":None,"zip":None,"staging":None,"manifest":None}
        def check():
            status.set("Checking GitHub…"); download_btn.config(state="disabled")
            def work():
                cand, errors=discover_ota()
                current=self.userdata.get("os_version",VERSION)
                if not cand:
                    self.after(0,lambda:(status.set("No OTA package was found. Make sure the ZIP is in direct/ on GitHub."),download_btn.config(state="normal")))
                    return
                newer=version_tuple(cand["version"])>version_tuple(current)
                if not newer:
                    self.after(0,lambda:(status.set(f"You're up to date. Installed {current}; newest available is {cand['version']}."),download_btn.config(state="normal")))
                    return
                state["candidate"]=cand
                self.after(0,lambda: (status.set(f"Update available: JamOS {cand['version']}\nChoose Download to begin."), download_btn.config(text=f"Download JamOS {cand['version']}", state="normal")))
            threading.Thread(target=work,daemon=True).start()
        def download():
            cand=state["candidate"]
            if not cand: return
            download_btn.config(state="disabled"); status.set(f"Downloading JamOS {cand['version']}…")
            def work():
                try:
                    fd,path=tempfile.mkstemp(suffix=".zip",prefix="jamos_ota_"); os.close(fd)
                    req=urllib.request.Request(cand["url"],headers={"User-Agent":"JamOS"})
                    with urllib.request.urlopen(req,timeout=30) as r, open(path,"wb") as out:
                        total=int(r.headers.get("Content-Length") or 0); done=0
                        while True:
                            chunk=r.read(256*1024)
                            if not chunk: break
                            out.write(chunk); done+=len(chunk)
                            pct=(done/total*100) if total else 0
                            self.after(0,lambda p=pct: bar.config(value=p))
                    state["zip"]=path
                    with zipfile.ZipFile(path) as z:
                        names=z.namelist(); setup_name=next((n for n in names if Path(n).name=="setup.txt"),None)
                        if not setup_name: raise ValueError("setup.txt is missing from the OTA ZIP.")
                        # Validate without extraction first
                        raw=z.read(setup_name).decode("utf-8")
                        mf={"version":None,"userdata_version":None,"files":[]}
                        for line in raw.splitlines():
                            line=line.strip()
                            if "=" not in line: continue
                            k,v=line.split("=",1); v=v.strip()
                            if k.strip()=="file": mf["files"].append(v.replace('\\','/'))
                            elif k.strip() in mf: mf[k.strip()]=v
                        if mf["version"] and version_tuple(mf["version"])!=version_tuple(cand["version"]): raise ValueError("OTA filename and setup.txt version do not match.")
                    status.set(f"Downloaded JamOS {cand['version']}.\nReady to install.")
                    install_btn.config(state="normal")
                    state["manifest"]=mf
                except Exception as e:
                    status.set(f"Download failed: {e}"); download_btn.config(state="normal")
            threading.Thread(target=work,daemon=True).start()
        def install():
            install_btn.config(state="disabled")
            try:
                with tempfile.TemporaryDirectory(dir=ROOT) as td:
                    td=Path(td); staging_root=td/"staging"; staging_root.mkdir()
                    # extract and detect optional wrapper directory
                    with zipfile.ZipFile(state["zip"]) as z:
                        z.extractall(staging_root)
                    setup=next(staging_root.rglob("setup.txt"),None)
                    if not setup: raise ValueError("setup.txt missing after extraction.")
                    staging=setup.parent
                    manifest=parse_manifest(setup)
                    install_from_staging(staging,manifest)
                self.userdata=load_userdata(); status.set("Update installed. Restarting JamOS…"); win.update_idletasks(); self.after(700,self.restart)
            except Exception as e:
                status.set(f"Install failed: {e}"); install_btn.config(state="normal")
        def restart(): self.restart()
        download_btn.config(command=check)
        # after first check its command changes to download
        original_check=check
        def dispatch():
            if state["candidate"] is None: original_check()
            else: download()
        download_btn.config(command=dispatch)
        install_btn.config(command=install)

    def restart(self):
        self.destroy()
        if getattr(sys, "frozen", False):
            subprocess.Popen([sys.executable])
        else:
            subprocess.Popen([sys.executable, str(Path(__file__).resolve())])


if __name__ == "__main__":
    ensure_dirs()
    save_userdata(load_userdata())
    app=JamOS()
    app.mainloop()
