JamOS no longer uses the HTML/webview interface.
