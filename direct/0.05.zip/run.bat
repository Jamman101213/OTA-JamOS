@echo off
pythonw "%~dp0main.py"
