import json, os, subprocess, sys, tempfile, threading, urllib.request, urllib.parse, webbrowser, zipfile, shutil, re
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox

APP='JamOS'; VERSION='0.06'; W=360; H=760
ROOT=Path(__file__).resolve().parent; UD=ROOT/'userdata'/'userdata.json'
API='https://api.github.com/repos/Jamman101213/OTA-JamOS/contents'
BG='#0f1115'; PANEL='#171a20'; PANEL2='#1d2129'; TEXT='#f5f7fb'; MUTED='#98a0ad'; ACCENT='#7c5cff'; LINE='#2a2f39'


def vt(v):
    a=[]
    for p in str(v).split('.'):
        try:a.append(int(p))
        except:a.append(0)
    return tuple(a)

def ensure():
    for p in [ROOT/'userdata',ROOT/'system',ROOT/'apps',ROOT/'cache']:
        p.mkdir(parents=True,exist_ok=True)

def load():
    ensure(); d={'os_version':VERSION,'name':'User','theme':'Dark','notes':'','wifi':True,'battery':87,'volume':70}
    try:d.update(json.loads(UD.read_text()))
    except:pass
    return d

def save():
    UD.write_text(json.dumps(user,indent=2))

def gj(url):
    req=urllib.request.Request(url,headers={'User-Agent':'JamOS'}); 
    with urllib.request.urlopen(req,timeout=15) as r:return json.loads(r.read().decode())

def latest():
    out=[]
    for loc in ('direct',''):
        try:
            data=gj(API+('/'+loc if loc else ''))
            if isinstance(data,list):
                for it in data:
                    n=it.get('name','')
                    if it.get('type')=='file' and n.endswith('.zip') and n[:-4][:1].isdigit():out.append((n[:-4],it.get('download_url')))
        except:pass
    return max(out,key=lambda x:vt(x[0])) if out else None

user=load()

class JamOS(tk.Tk):
    def __init__(self):
        super().__init__(); self.title('JamOS'); self.geometry(f'{W}x{H}'); self.resizable(False,False); self.configure(bg=BG); self.protocol('WM_DELETE_WINDOW',self.destroy); self.style(); self.page='home'; self.build(); self.home()
    def style(self):
        s=ttk.Style(self); 
        try:s.theme_use('clam')
        except:pass
        s.configure('TProgressbar',troughcolor=LINE,background=ACCENT,bordercolor=LINE,lightcolor=ACCENT,darkcolor=ACCENT)
    def clear(self):
        for w in self.content.winfo_children():w.destroy()
    def build(self):
        top=tk.Frame(self,bg=BG,height=48); top.pack(fill='x'); top.pack_propagate(False)
        self.clock=tk.Label(top,bg=BG,fg=TEXT,font=('Segoe UI Semibold',10)); self.clock.pack(side='left',padx=16)
        self.status=tk.Label(top,bg=BG,fg=MUTED,font=('Segoe UI',9)); self.status.pack(side='right',padx=14)
        self.content=tk.Frame(self,bg=BG); self.content.pack(fill='both',expand=True)
        nav=tk.Frame(self,bg=PANEL,height=64); nav.pack(fill='x',side='bottom'); nav.pack_propagate(False)
        for label,fn in [('Home',self.home),('Apps',self.apps),('Phone',self.phone),('Settings',self.settings)]:
            tk.Button(nav,text=label,command=fn,bg=PANEL,fg=MUTED,activebackground=PANEL2,activeforeground=TEXT,relief='flat',font=('Segoe UI Semibold',9)).pack(side='left',fill='both',expand=True,pady=8)
        self.after(500,self.tick)
    def tick(self):
        self.clock.config(text=datetime.now().strftime('%I:%M %p').lstrip('0')); self.status.config(text=f"Wi-Fi  {user.get('battery',87)}%  •  {user.get('os_version',VERSION)}"); self.after(1000,self.tick)
    def header(self,title,sub=None):
        tk.Label(self.content,text=title,bg=BG,fg=TEXT,font=('Segoe UI Semibold',22)).pack(anchor='w',padx=16,pady=(8,0))
        if sub:tk.Label(self.content,text=sub,bg=BG,fg=MUTED,font=('Segoe UI',9)).pack(anchor='w',padx=16,pady=(2,12))
    def card(self,parent,text,cmd=None):
        b=tk.Button(parent,text=text,command=cmd,bg=PANEL,fg=TEXT,activebackground=PANEL2,activeforeground=TEXT,relief='flat',anchor='w',padx=14,pady=12,font=('Segoe UI',10))
        b.pack(fill='x',pady=4); return b
    def home(self):
        self.page='home'; self.clear(); self.header('Good day',user.get('name','User'))
        quick=tk.Frame(self.content,bg=BG); quick.pack(fill='x',padx=12,pady=8)
        items=[('Browser',self.browser),('Messages',self.messages),('Camera',self.camera),('Music',self.music)]
        for i,(n,f) in enumerate(items):
            b=tk.Button(quick,text=n,command=f,bg=PANEL,fg=TEXT,activebackground=PANEL2,relief='flat',font=('Segoe UI Semibold',9),pady=14); b.grid(row=i//2,column=i%2,sticky='ew',padx=4,pady=4)
        quick.columnconfigure(0,weight=1); quick.columnconfigure(1,weight=1)
        self.card(self.content,'Continue in Apps  →',self.apps)
        self.card(self.content,'Check for OTA updates  →',self.updates)
        self.card(self.content,'Open Files  →',self.files)
    def apps(self):
        self.page='apps'; self.clear(); self.header('Apps','Everything built into this JamOS demo')
        grid=tk.Frame(self.content,bg=BG); grid.pack(fill='both',expand=True,padx=10)
        data=[('Browser',self.browser),('Phone',self.phone),('Messages',self.messages),('Contacts',self.contacts),('Camera',self.camera),('Gallery',self.gallery),('Music',self.music),('Clock',self.clockapp),('Calendar',self.calendar),('Calculator',self.calculator),('Notes',self.notes),('Files',self.files),('Downloads',self.downloads),('Settings',self.settings),('Updates',self.updates),('About',self.about),('Weather',self.weather),('Store',self.store),('Terminal',self.terminal),('Recorder',self.recorder)]
        for i,(n,f) in enumerate(data):
            r,c=divmod(i,2); tk.Button(grid,text=n,command=f,bg=PANEL,fg=TEXT,activebackground=PANEL2,relief='flat',font=('Segoe UI Semibold',9),pady=13).grid(row=r,column=c,sticky='ew',padx=4,pady=4)
        grid.columnconfigure(0,weight=1);grid.columnconfigure(1,weight=1)
    def popup(self,title,size='620x460'):
        w=tk.Toplevel(self);w.title(title);w.geometry(size);w.configure(bg=BG);w.resizable(False,False);return w
    def browser(self):
        w=self.popup('JamOS Browser','760x560'); top=tk.Frame(w,bg=PANEL,padx=10,pady=10);top.pack(fill='x'); e=tk.Entry(top,bg='#0b0d11',fg=TEXT,insertbackground=TEXT,relief='flat');e.pack(side='left',fill='x',expand=True,ipady=8);e.insert(0,'https://www.google.com');
        def go():
            u=e.get().strip(); u=u if re.match(r'^https?://',u) else 'https://www.google.com/search?q='+urllib.parse.quote(u)
            webbrowser.open(u)
        tk.Button(top,text='Open',command=go,bg=ACCENT,fg='white',relief='flat',padx=16,pady=8).pack(side='right',padx=(8,0))
        tk.Label(w,text='Browser opens links using your Windows default browser.',bg=BG,fg=MUTED).pack(anchor='w',padx=14,pady=14)
    def phone(self):
        w=self.popup('Phone'); tk.Label(w,text='Phone',bg=BG,fg=TEXT,font=('Segoe UI Semibold',22)).pack(anchor='w',padx=18,pady=16); e=tk.Entry(w,bg=PANEL,fg=TEXT,relief='flat',justify='center',font=('Segoe UI',18));e.pack(fill='x',padx=18,pady=10,ipady=8); tk.Button(w,text='Call',command=lambda:messagebox.showinfo('Phone','Call simulation started.'),bg=ACCENT,fg='white',relief='flat',pady=10).pack(fill='x',padx=18)
    def messages(self): self.simple('Messages','No conversations yet.\nThis is a local phone-emulator demo.')
    def contacts(self): self.simple('Contacts','Add contacts later.\nThe app shell is ready for contact storage.')
    def camera(self): self.simple('Camera','Camera preview placeholder.\nA native camera integration can be added later.')
    def gallery(self): self.simple('Gallery','No photos yet.')
    def music(self): self.simple('Music','Library empty.\nDrop audio files into your JamOS media folder later.')
    def clockapp(self): self.simple('Clock',datetime.now().strftime('%A\n%B %d, %Y\n%I:%M:%S %p'))
    def calendar(self): self.simple('Calendar',datetime.now().strftime('%B %Y\n\nToday: %A, %B %d'))
    def calculator(self):
        w=self.popup('Calculator','360x460');v=tk.StringVar();e=tk.Entry(w,textvariable=v,bg=PANEL,fg=TEXT,insertbackground=TEXT,relief='flat',justify='right',font=('Segoe UI',18));e.pack(fill='x',padx=12,pady=12,ipady=10)
        for row in [('7','8','9','/'),('4','5','6','*'),('1','2','3','-'),('0','.','=','+')]:
            fr=tk.Frame(w,bg=BG);fr.pack(fill='x',padx=8)
            for x in row:
                def add(ch=x):
                    if ch=='=':
                        try:v.set(str(eval(v.get(),{'__builtins__':{}},{})))
                        except:v.set('Error')
                    else:v.set(v.get()+ch)
                tk.Button(fr,text=x,command=add,bg=PANEL,fg=TEXT,relief='flat',font=('Segoe UI Semibold',12),pady=14).pack(side='left',fill='x',expand=True,padx=2,pady=2)
    def notes(self):
        w=self.popup('Notes','620x500');t=tk.Text(w,bg='#101218',fg=TEXT,insertbackground=TEXT,relief='flat',wrap='word');t.pack(fill='both',expand=True,padx=12,pady=12);t.insert('1.0',user.get('notes','')); tk.Button(w,text='Save',command=lambda:(user.__setitem__('notes',t.get('1.0','end-1c')),save(),w.destroy()),bg=ACCENT,fg='white',relief='flat',pady=9).pack(fill='x',padx=12,pady=(0,12))
    def files(self):
        os.startfile(str(ROOT)) if os.name=='nt' else subprocess.Popen(['xdg-open',str(ROOT)])
    def downloads(self): self.simple('Downloads',str(ROOT/'cache'))
    def about(self): self.simple('About',f'JamOS\nVersion {user.get("os_version",VERSION)}\n\nNative Tkinter phone-emulator shell.')
    def weather(self): self.simple('Weather','Weather service is offline in this build.\nYou can open a weather site in Browser.')
    def store(self): self.simple('JamOS Store','App store placeholder.\nOTA is the system update channel.')
    def terminal(self): self.simple('Terminal','JamOS Terminal placeholder.\nPython apps can be added under apps/.')
    def recorder(self): self.simple('Recorder','Audio recorder placeholder.')
    def simple(self,title,text):
        w=self.popup(title); tk.Label(w,text=text,bg=BG,fg=TEXT,font=('Segoe UI',12),justify='left').pack(anchor='nw',padx=18,pady=18)
    def settings(self):
        self.clear(); self.header('Settings','Customize your JamOS session')
        for title,key,vals in [('Theme','theme',['Dark']),('Wi-Fi','wifi',[True,False])]:
            row=tk.Frame(self.content,bg=PANEL);row.pack(fill='x',padx=14,pady=5);tk.Label(row,text=title,bg=PANEL,fg=TEXT).pack(side='left',padx=12,pady=14)
            var=tk.StringVar(value=str(user.get(key)))
            cb=ttk.Combobox(row,values=[str(v) for v in vals],textvariable=var,state='readonly',width=12);cb.pack(side='right',padx=12)
            def change(k=key,v=var):
                user[k]=v.get(); save()
            cb.bind('<<ComboboxSelected>>',lambda e,c=change:c())
        self.card(self.content,'Software Updates',self.updates); self.card(self.content,'Open JamOS folder',self.files)
    def updates(self):
        self.clear(); self.header('Software Update','GitHub OTA channel'); self.info=tk.Label(self.content,text='Checking…',bg=BG,fg=MUTED,justify='left');self.info.pack(anchor='w',padx=16,pady=12);self.bar=ttk.Progressbar(self.content,maximum=100);self.bar.pack(fill='x',padx=16,pady=8); self.action=tk.Button(self.content,text='Check again',command=self.check,bg=ACCENT,fg='white',relief='flat',pady=10);self.action.pack(fill='x',padx=16,pady=12);self.check()
    def check(self):
        self.action.config(state='disabled'); self.info.config(text='Checking GitHub…')
        def work():
            cand=latest(); cur=user.get('os_version',VERSION)
            if not cand:
                self.after(0,lambda:self.done('No OTA package found.'));return
            ver,url=cand
            if vt(ver)<=vt(cur): self.after(0,lambda:self.done(f'You are up to date.\nInstalled: {cur}\nLatest: {ver}'));return
            self.after(0,lambda:self.offer(ver,url))
        threading.Thread(target=work,daemon=True).start()
    def done(self,msg): self.info.config(text=msg);self.action.config(state='normal',text='Check again')
    def offer(self,ver,url):
        self.info.config(text=f'JamOS {ver} is available.\nNothing will download until you choose Update.'); self.action.config(state='normal',text=f'Download & Update to {ver}',command=lambda:self.download(ver,url))
    def download(self,ver,url):
        self.action.config(state='disabled');self.info.config(text=f'Downloading JamOS {ver}…');self.bar['value']=0
        def work():
            try:
                fd,path=tempfile.mkstemp(prefix='jamos_ota_',suffix='.zip');os.close(fd)
                req=urllib.request.Request(url,headers={'User-Agent':'JamOS'}); done=0
                with urllib.request.urlopen(req,timeout=40) as r,open(path,'wb') as out:
                    total=int(r.headers.get('Content-Length') or 0)
                    while True:
                        ch=r.read(256*1024)
                        if not ch:break
                        out.write(ch);done+=len(ch);p=done/total*100 if total else 0;self.after(0,lambda p=p:self.bar.config(value=p))
                with zipfile.ZipFile(path) as z:
                    setup=z.read(next(n for n in z.namelist() if Path(n).name=='setup.txt')).decode();
                    mv=re.search(r'^version=(.+)$',setup,re.M).group(1).strip()
                    if vt(mv)!=vt(ver): raise ValueError('OTA version mismatch')
                self.after(0,lambda:self.apply(path,ver))
            except Exception as e:self.after(0,lambda e=e:self.done(f'Update failed: {e}'))
        threading.Thread(target=work,daemon=True).start()
    def apply(self,path,ver):
        self.info.config(text=f'JamOS {ver} downloaded.\nApplying update and restarting…');
        try:
            helper=ROOT/'updater.py'
            subprocess.Popen([sys.executable,str(helper),'apply',path,str(os.getpid())],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)); self.after(300,self.destroy)
        except Exception as e:self.done(f'Could not start updater: {e}')

app=JamOS(); app.mainloop()
