import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO_API = "https://api.github.com/repos/Jamman101213/OTA-JamOS/contents"


def vt(v):
    out=[]
    for x in str(v).strip().split('.'):
        try: out.append(int(x))
        except ValueError: out.append(0)
    return tuple(out)


def get_json(url):
    req=urllib.request.Request(url,headers={"User-Agent":"JamOS-Updater"})
    with urllib.request.urlopen(req,timeout=20) as r:
        return json.loads(r.read().decode())


def find_latest():
    found=[]; seen=set()
    for loc in ("direct", ""):
        try:
            data=get_json(REPO_API+('/'+loc if loc else ''))
            if not isinstance(data,list): continue
            for it in data:
                name=it.get('name','')
                if it.get('type')!='file' or not name.lower().endswith('.zip'): continue
                stem=name[:-4]
                if not stem or not stem[0].isdigit() or name in seen: continue
                seen.add(name); found.append((stem,it.get('download_url')))
        except Exception:
            pass
    return max(found,key=lambda x:vt(x[0])) if found else None


def parse_manifest(root):
    p=root/'setup.txt'
    if not p.exists(): raise ValueError('setup.txt is missing from the OTA package.')
    m={'version':None,'userdata_version':None,'files':[]}
    for raw in p.read_text(encoding='utf-8').splitlines():
        line=raw.strip()
        if not line or line.startswith('#') or '=' not in line: continue
        k,v=line.split('=',1); k=k.strip(); v=v.strip()
        if k=='file': m['files'].append(v.replace('\\','/').lstrip('/'))
        elif k in m: m[k]=v
    if not m['version'] or not m['files']: raise ValueError('Invalid setup.txt.')
    return m


def locate_setup(td):
    direct=td/'setup.txt'
    if direct.exists(): return td
    hits=list(td.rglob('setup.txt'))
    if not hits: raise ValueError('setup.txt is missing from the OTA package.')
    return hits[0].parent


def apply_package(zip_path):
    with tempfile.TemporaryDirectory(prefix='jamos_apply_') as td:
        td=Path(td)
        with zipfile.ZipFile(zip_path) as z:
            z.extractall(td)
        staging=locate_setup(td)
        manifest=parse_manifest(staging)
        if vt(manifest['version']) < vt('0.06'):
            raise ValueError('This updater only applies JamOS 0.06 or newer packages.')
        expected=set()
        for rel in manifest['files']:
            rel=rel.replace('\\','/').lstrip('/')
            if Path(rel).name=='.gitkeep':
                (ROOT/Path(rel).parent).mkdir(parents=True,exist_ok=True)
                continue
            src=staging/Path(rel)
            if not src.is_file(): raise ValueError(f'Package is missing: {rel}')
            expected.add(rel)
        backup=ROOT/'.ota_backup'
        if backup.exists(): shutil.rmtree(backup,ignore_errors=True)
        backup.mkdir(parents=True,exist_ok=True)
        # Managed tree; preserve user data and updater itself.
        preserve={'userdata','.ota_backup','updater.py','updater.pyw'}
        for child in list(ROOT.iterdir()):
            if child.name in preserve: continue
            rel=child.relative_to(ROOT).as_posix()
            managed=(child.is_file() or child.name in {'system','apps','web','cache'})
            if managed and rel not in expected and child.name!='setup.txt':
                dest=backup/rel; dest.parent.mkdir(parents=True,exist_ok=True)
                try: shutil.move(str(child),str(dest))
                except Exception:
                    if child.is_dir(): shutil.rmtree(child,ignore_errors=True)
                    else: child.unlink(missing_ok=True)
        for rel in expected:
            src=staging/Path(rel); dst=ROOT/Path(rel)
            dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
        ud=ROOT/'userdata'/'userdata.json'; ud.parent.mkdir(parents=True,exist_ok=True)
        data={}
        try: data=json.loads(ud.read_text(encoding='utf-8'))
        except Exception: pass
        data['os_version']=manifest.get('userdata_version') or manifest['version']
        ud.write_text(json.dumps(data,indent=2),encoding='utf-8')
        (ROOT/'setup.txt').unlink(missing_ok=True)
        shutil.rmtree(backup,ignore_errors=True)


def main():
    if len(sys.argv)<2: return
    mode=sys.argv[1]
    if mode=='apply' and len(sys.argv)>=3:
        zip_path=Path(sys.argv[2]); pid=int(sys.argv[3]) if len(sys.argv)>=4 else 0
        # Wait for JamOS to exit so Windows releases main.py and related files.
        if pid and os.name=='nt':
            for _ in range(80):
                try:
                    import ctypes
                    PROCESS_QUERY_LIMITED_INFORMATION=0x1000
                    h=ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,False,pid)
                    if not h: break
                    ctypes.windll.kernel32.CloseHandle(h)
                    time.sleep(0.25)
                except Exception: break
        apply_package(zip_path)
        subprocess.Popen([sys.executable,str(ROOT/'main.py')],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        try: zip_path.unlink(missing_ok=True)
        except Exception: pass

if __name__=='__main__':
    try: main()
    except Exception as e:
        # best effort: write a simple error file for diagnostics
        try: (ROOT/'system'/'ota_error.txt').write_text(str(e),encoding='utf-8')
        except Exception: pass
