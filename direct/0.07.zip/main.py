import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from pathlib import Path
import json, os, subprocess, sys, time, urllib.request, urllib.parse, re, webbrowser, threading, html

APP_VERSION = "0.07"
BASE = Path(__file__).resolve().parent
DATA = BASE / "userdata"
DATA.mkdir(exist_ok=True)
USERDATA = DATA / "userdata.json"
DOWNLOADS = BASE / "downloads"
FILES = BASE / "files"
DOWNLOADS.mkdir(exist_ok=True); FILES.mkdir(exist_ok=True)

def load_data():
    default = {"version": APP_VERSION, "theme": "Midnight", "wallpaper": "default", "notes": "", "contacts": [], "messages": [], "recent_apps": [], "wifi": True, "bluetooth": False, "brightness": 80}
    try:
        d = json.loads(USERDATA.read_text(encoding='utf-8'))
        default.update(d)
    except Exception:
        pass
    return default

def save_data():
    USERDATA.write_text(json.dumps(state, indent=2), encoding='utf-8')

state = load_data()

THEMES = {
    "Midnight": {"bg":"#0d1117","panel":"#151b23","card":"#1b2430","fg":"#f3f6fa","muted":"#8f9baa","accent":"#8b7cff","accent2":"#b9b1ff","danger":"#ff667a","input":"#111821"},
    "Graphite": {"bg":"#101214","panel":"#191c20","card":"#22262b","fg":"#f2f3f5","muted":"#9ba1a9","accent":"#d8dee9","accent2":"#ffffff","danger":"#ff667a","input":"#16191d"},
    "Ocean": {"bg":"#07151e","panel":"#0d202c","card":"#123244","fg":"#e9fbff","muted":"#86aab8","accent":"#45c7ff","accent2":"#9be7ff","danger":"#ff6b7d","input":"#0b1b25"},
    "Forest": {"bg":"#0b1711","panel":"#122119","card":"#183024","fg":"#effff3","muted":"#91ad99","accent":"#5bd38d","accent2":"#a6efc4","danger":"#ff7a75","input":"#0e1b14"},
    "Sunset": {"bg":"#1b100e","panel":"#281714","card":"#38201a","fg":"#fff4ee","muted":"#b79b90","accent":"#ff976d","accent2":"#ffd0be","danger":"#ff647a","input":"#21120f"},
}
T = THEMES.get(state.get('theme'), THEMES['Midnight'])

class IconButton(tk.Canvas):
    def __init__(self, master, glyph, command, size=44, bg=None, fg=None, hover=None):
        super().__init__(master, width=size, height=size, bg=bg or T['panel'], highlightthickness=0)
        self.glyph=glyph; self.command=command; self.fg=fg or T['fg']; self.hover=hover or T['card']; self.bg0=bg or T['panel']
        self.create_oval(3,3,size-3,size-3,fill=self.bg0,outline=self.bg0)
        self.txt=self.create_text(size/2,size/2,text=glyph,fill=self.fg,font=("Segoe UI Symbol", int(size*0.34)))
        self.bind('<Button-1>', lambda e: self.command())
        self.bind('<Enter>', lambda e: self.itemconfig(1,fill=self.hover,outline=self.hover))
        self.bind('<Leave>', lambda e: self.itemconfig(1,fill=self.bg0,outline=self.bg0))

class JamOS(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("JamOS 0.07")
        self.geometry("430x820")
        self.minsize(430,820); self.maxsize(430,820); self.resizable(False,False)
        self.configure(bg=T['bg'])
        self.protocol('WM_DELETE_WINDOW', self.destroy)
        self.pages={}; self.current=None; self.prev_page='home'; self.notifications=[]
        self.style = ttk.Style(self)
        try: self.style.theme_use('clam')
        except: pass
        self._configure_style()
        self.build_shell()
        self.show_home()
        self.after(1200, self.clock_tick)
        self.after(2600, self.demo_notification)

    def _configure_style(self):
        self.style.configure('TLabel', background=T['bg'], foreground=T['fg'], font=('Segoe UI', 10))
        self.style.configure('Title.TLabel', background=T['bg'], foreground=T['fg'], font=('Segoe UI Semibold', 22))
        self.style.configure('Sub.TLabel', background=T['bg'], foreground=T['muted'], font=('Segoe UI', 9))
        self.style.configure('Card.TFrame', background=T['card'])
        self.style.configure('TButton', background=T['card'], foreground=T['fg'], padding=8, borderwidth=0, font=('Segoe UI', 10))
        self.style.map('TButton', background=[('active', T['panel'])])
        self.style.configure('Accent.TButton', background=T['accent'], foreground='#0b0d10', padding=10, borderwidth=0, font=('Segoe UI Semibold', 10))
        self.style.map('Accent.TButton', background=[('active', T['accent2'])])
        self.style.configure('TEntry', fieldbackground=T['input'], foreground=T['fg'], insertcolor=T['fg'], borderwidth=1)
        self.style.configure('TNotebook', background=T['bg'], borderwidth=0)
        self.style.configure('TScale', background=T['panel'], troughcolor=T['input'])

    def rebuild(self):
        for w in self.winfo_children(): w.destroy()
        self._configure_style(); self.build_shell(); self.show_home()

    def build_shell(self):
        top=tk.Frame(self,bg=T['panel'],height=38); top.pack(fill='x'); top.pack_propagate(False)
        self.time_lbl=tk.Label(top,bg=T['panel'],fg=T['fg'],font=('Segoe UI Semibold',11)); self.time_lbl.pack(side='left',padx=12)
        right=tk.Frame(top,bg=T['panel']); right.pack(side='right',padx=8)
        self.net=tk.Label(right,text='⌁  ◉  ▮',bg=T['panel'],fg=T['muted'],font=('Segoe UI',10)); self.net.pack(side='left',padx=5)
        IconButton(right,'⋯',self.toggle_notifications,size=34,bg=T['panel'],fg=T['fg']).pack(side='left')
        self.body=tk.Frame(self,bg=T['bg']); self.body.pack(fill='both',expand=True)
        nav=tk.Frame(self,bg=T['panel'],height=66); nav.pack(fill='x',side='bottom'); nav.pack_propagate(False)
        self.nav_buttons=[]
        for glyph,label,cmd in [('⌂','Home',self.show_home),('▦','Apps',self.show_apps),('◫','Recents',self.show_recents),('⚙','Settings',self.show_settings)]:
            b=tk.Frame(nav,bg=T['panel']); b.pack(side='left',expand=True,fill='both')
            IconButton(b,glyph,cmd,size=34,bg=T['panel'],fg=T['muted'],hover=T['card']).pack(pady=(6,0))
            tk.Label(b,text=label,bg=T['panel'],fg=T['muted'],font=('Segoe UI',8)).pack()

    def clear_body(self):
        for w in self.body.winfo_children(): w.destroy()

    def header(self,title,subtitle=None,back=True):
        bar=tk.Frame(self.body,bg=T['bg']); bar.pack(fill='x',padx=18,pady=(16,8))
        if back:
            IconButton(bar,'‹',lambda:self.show_page(self.prev_page),size=38,bg=T['bg'],hover=T['card']).pack(side='left')
        tk.Label(bar,text=title,bg=T['bg'],fg=T['fg'],font=('Segoe UI Semibold',19)).pack(side='left',padx=10)
        if subtitle: tk.Label(self.body,text=subtitle,bg=T['bg'],fg=T['muted'],font=('Segoe UI',9)).pack(anchor='w',padx=20,pady=(0,8))

    def tile(self,parent,name,glyph,command):
        f=tk.Frame(parent,bg=T['card'],width=116,height=108); f.pack_propagate(False)
        IconButton(f,glyph,command,size=52,bg=T['card'],fg=T['accent'],hover=T['panel']).pack(pady=(10,2))
        tk.Label(f,text=name,bg=T['card'],fg=T['fg'],font=('Segoe UI Semibold',9)).pack()
        return f

    def show_page(self,name):
        getattr(self, 'show_'+name)()

    def show_home(self):
        self.clear_body(); self.current='home'
        hero=tk.Frame(self.body,bg=T['bg']); hero.pack(fill='x',padx=20,pady=(18,10))
        tk.Label(hero,text='JamOS',bg=T['bg'],fg=T['fg'],font=('Segoe UI Semibold',28)).pack(anchor='w')
        tk.Label(hero,text=time.strftime('%A, %B %d'),bg=T['bg'],fg=T['muted'],font=('Segoe UI',10)).pack(anchor='w')
        quick=tk.Frame(self.body,bg=T['bg']); quick.pack(fill='x',padx=18,pady=12)
        qitems=[('☎','Phone',self.show_phone),('✉','Messages',self.show_messages),('◎','Browser',self.show_browser),('⌕','Files',self.show_files)]
        for g,n,c in qitems: self.tile(quick,n,g,c).pack(side='left',expand=True,fill='both',padx=4)
        section=tk.Frame(self.body,bg=T['bg']); section.pack(fill='x',padx=20,pady=(6,6))
        tk.Label(section,text='Your apps',bg=T['bg'],fg=T['fg'],font=('Segoe UI Semibold',13)).pack(side='left')
        ttk.Button(section,text='All apps',command=self.show_apps).pack(side='right')
        grid=tk.Frame(self.body,bg=T['bg']); grid.pack(fill='both',expand=True,padx=18)
        apps=[('▣','Camera',self.show_camera),('▤','Gallery',self.show_gallery),('♪','Music',self.show_music),('✓','Notes',self.show_notes),('▦','Calendar',self.show_calendar),('◷','Clock',self.show_clock),('◉','Weather',self.show_weather),('⌘','Terminal',self.show_terminal)]
        for i,(g,n,c) in enumerate(apps):
            self.tile(grid,n,g,c).grid(row=i//4,column=i%4,padx=4,pady=4,sticky='nsew')
        for i in range(4): grid.grid_columnconfigure(i,weight=1)

    def show_apps(self):
        self.clear_body(); self.current='apps'; self.header('Apps','Native JamOS apps')
        canvas=tk.Canvas(self.body,bg=T['bg'],highlightthickness=0); canvas.pack(fill='both',expand=True,padx=10,pady=5)
        frame=tk.Frame(canvas,bg=T['bg']); canvas.create_window((0,0),window=frame,anchor='nw')
        apps=[
            ('☎','Phone',self.show_phone),('✉','Messages',self.show_messages),('◌','Contacts',self.show_contacts),('◎','Browser',self.show_browser),
            ('▣','Camera',self.show_camera),('▤','Gallery',self.show_gallery),('♪','Music',self.show_music),('☷','Recorder',self.show_recorder),
            ('✓','Notes',self.show_notes),('▦','Calendar',self.show_calendar),('◷','Clock',self.show_clock),('◉','Weather',self.show_weather),
            ('⌕','Files',self.show_files),('⇩','Downloads',self.show_downloads),('⌘','Terminal',self.show_terminal),('⊞','Store',self.show_store),
            ('⚙','Settings',self.show_settings),('↻','Updates',self.show_updates),('⌂','Maps',self.show_maps),('▣','Mail',self.show_mail),
            ('⌁','Wi‑Fi',self.show_wifi),('▰','Device',self.show_device),('☀','Display',self.show_display),('!','About',self.show_about)
        ]
        for i,(g,n,c) in enumerate(apps):
            self.tile(frame,n,g,c).grid(row=i//4,column=i%4,padx=4,pady=4)
        frame.update_idletasks(); canvas.configure(scrollregion=canvas.bbox('all'))
        canvas.bind_all('<MouseWheel>',lambda e: canvas.yview_scroll(-int(e.delta/120),'units'))

    def simple_page(self,title,lines,back=True):
        self.clear_body(); self.header(title, back=back)
        card=tk.Frame(self.body,bg=T['card']); card.pack(fill='both',expand=True,padx=20,pady=10)
        for text in lines: tk.Label(card,text=text,bg=T['card'],fg=T['fg'],font=('Segoe UI',11),wraplength=360,justify='left').pack(anchor='w',padx=18,pady=8)

    def show_recents(self):
        self.clear_body(); self.header('Recent apps','Quickly reopen the apps you used')
        recent=state.get('recent_apps',[])[:8]
        if not recent: tk.Label(self.body,text='No recent apps yet.',bg=T['bg'],fg=T['muted']).pack(pady=40)
        for n in recent:
            ttk.Button(self.body,text=n,command=lambda x=n:self.launch_by_name(x)).pack(fill='x',padx=20,pady=4)

    def launch_by_name(self,n):
        mapping={k[0]:k[2] for k in [('Phone','☎',self.show_phone)]}
        for title,method in [(x[0],x[2]) for x in [
            ('Phone','☎',self.show_phone),('Messages','✉',self.show_messages),('Contacts','◌',self.show_contacts),('Browser','◎',self.show_browser),('Camera','▣',self.show_camera),('Gallery','▤',self.show_gallery),('Music','♪',self.show_music),('Recorder','☷',self.show_recorder),('Notes','✓',self.show_notes),('Calendar','▦',self.show_calendar),('Clock','◷',self.show_clock),('Weather','◉',self.show_weather),('Files','⌕',self.show_files),('Downloads','⇩',self.show_downloads),('Terminal','⌘',self.show_terminal),('Store','⊞',self.show_store),('Settings','⚙',self.show_settings),('Updates','↻',self.show_updates),('Maps','⌂',self.show_maps),('Mail','▣',self.show_mail),('Wi‑Fi','⌁',self.show_wifi),('Device','▰',self.show_device),('Display','☀',self.show_display),('About','! ',self.show_about)]]:
            if title==n: method(); return

    def track(self,name):
        recent=state.setdefault('recent_apps',[]); state['recent_apps']=[name]+[x for x in recent if x!=name]; state['recent_apps']=state['recent_apps'][:8]; save_data()

    def make_app_header(self,title): self.header(title); self.track(title)

    def show_phone(self):
        self.clear_body(); self.make_app_header('Phone')
        disp=tk.StringVar(value='')
        e=ttk.Entry(self.body,textvariable=disp,font=('Segoe UI',20),justify='right'); e.pack(fill='x',padx=25,pady=10)
        f=tk.Frame(self.body,bg=T['bg']); f.pack(padx=20,pady=8)
        keys=['1','2','3','4','5','6','7','8','9','*','0','#']
        for i,k in enumerate(keys): ttk.Button(f,text=k,width=8,command=lambda x=k:disp.set(disp.get()+x)).grid(row=i//3,column=i%3,padx=4,pady=4)
        ttk.Button(self.body,text='Clear',command=lambda:disp.set('')).pack(pady=6)
        ttk.Button(self.body,text='Call',style='Accent.TButton',command=lambda:self.incoming_call_sim(disp.get() or 'Unknown')).pack(fill='x',padx=65,pady=6)
    def incoming_call_sim(self,who):
        w=tk.Toplevel(self); w.title('Incoming call'); w.geometry('300x310'); w.resizable(False,False); w.configure(bg=T['panel']);
        tk.Label(w,text='Incoming call',bg=T['panel'],fg=T['muted'],font=('Segoe UI',10)).pack(pady=(22,5))
        tk.Label(w,text=who,bg=T['panel'],fg=T['fg'],font=('Segoe UI Semibold',22)).pack(pady=8)
        tk.Label(w,text='☎',bg=T['panel'],fg=T['accent'],font=('Segoe UI Symbol',42)).pack(pady=8)
        f=tk.Frame(w,bg=T['panel']); f.pack(pady=8)
        ttk.Button(f,text='Decline',command=w.destroy).pack(side='left',padx=5)
        ttk.Button(f,text='Answer',style='Accent.TButton',command=lambda:[w.destroy(),messagebox.showinfo('Call','Call connected.\nJamOS call simulator.')]).pack(side='left',padx=5)

    def show_messages(self):
        self.clear_body(); self.make_app_header('Messages')
        msgs=state.get('messages',[])
        box=tk.Listbox(self.body,bg=T['input'],fg=T['fg'],selectbackground=T['accent'],height=12,borderwidth=0,font=('Segoe UI',10)); box.pack(fill='both',expand=True,padx=20,pady=8)
        for m in msgs: box.insert('end',f"{m.get('from','Unknown')}: {m.get('text','')}")
        f=tk.Frame(self.body,bg=T['bg']); f.pack(fill='x',padx=20,pady=10)
        to=ttk.Entry(f); to.pack(side='left',fill='x',expand=True); text=ttk.Entry(f); text.pack(side='left',fill='x',expand=True,padx=5)
        def send():
            if text.get().strip(): state.setdefault('messages',[]).append({'from':to.get() or 'Me','text':text.get()}); save_data(); self.show_messages()
        ttk.Button(f,text='Send',command=send).pack(side='right')
    def show_contacts(self):
        self.clear_body(); self.make_app_header('Contacts')
        box=tk.Listbox(self.body,bg=T['input'],fg=T['fg'],selectbackground=T['accent'],borderwidth=0); box.pack(fill='both',expand=True,padx=20,pady=8)
        for c in state.get('contacts',[]): box.insert('end',f"{c.get('name')}  ·  {c.get('number')}")
        def add():
            n=simpledialog.askstring('Contact','Name:'); num=simpledialog.askstring('Contact','Number:')
            if n and num: state.setdefault('contacts',[]).append({'name':n,'number':num}); save_data(); self.show_contacts()
        ttk.Button(self.body,text='＋ Add contact',style='Accent.TButton',command=add).pack(pady=8)
    def show_browser(self):
        self.clear_body(); self.make_app_header('Browser')
        f=tk.Frame(self.body,bg=T['bg']); f.pack(fill='x',padx=18,pady=4)
        url=ttk.Entry(f); url.pack(side='left',fill='x',expand=True); ttk.Button(f,text='Go',command=lambda:load()).pack(side='right',padx=5)
        out=tk.Text(self.body,bg=T['input'],fg=T['fg'],insertbackground=T['fg'],wrap='word',borderwidth=0); out.pack(fill='both',expand=True,padx=18,pady=8)
        out.insert('end','JamOS Browser\n\nEnter a URL, or type a search. Pages are rendered as clean native text.\n')
        def load():
            target=url.get().strip();
            if not target: return
            if '://' not in target:
                if '.' not in target or ' ' in target: target='https://www.google.com/search?q='+urllib.parse.quote(target)
                else: target='https://'+target
            out.delete('1.0','end'); out.insert('end',f'Loading {target}…\n\n')
            def worker():
                try:
                    req=urllib.request.Request(target,headers={'User-Agent':'JamOS/0.07'})
                    data=urllib.request.urlopen(req,timeout=8).read(500000).decode('utf-8','replace')
                    data=re.sub(r'<(script|style).*?</\1>',' ',data,flags=re.S|re.I); data=re.sub(r'<br\s*/?>','\n',data,flags=re.I); data=re.sub(r'<[^>]+>',' ',data); data=html.unescape(re.sub(r'\s+',' ',data));
                    self.after(0,lambda: (out.delete('1.0','end'),out.insert('end',data.strip()[:20000])))
                except Exception as ex: self.after(0,lambda: (out.delete('1.0','end'),out.insert('end',f'Could not load page.\n\n{ex}')))
            threading.Thread(target=worker,daemon=True).start()
    def show_camera(self):
        self.simple_page('Camera',['Camera simulator','This native JamOS camera preview is simulated.','Capture creates a timestamped text placeholder in Gallery.'],True)
        ttk.Button(self.body,text='◎ Capture',style='Accent.TButton',command=self.capture).pack(pady=10)
    def capture(self):
        p=FILES/f'photo_{time.strftime("%Y%m%d_%H%M%S")}.txt'; p.write_text('JamOS simulated photo capture',encoding='utf-8'); messagebox.showinfo('Camera','Photo captured and saved to Gallery.')
    def show_gallery(self):
        self.clear_body(); self.make_app_header('Gallery');
        files=sorted(FILES.glob('*'),reverse=True); box=tk.Listbox(self.body,bg=T['input'],fg=T['fg'],selectbackground=T['accent'],borderwidth=0); box.pack(fill='both',expand=True,padx=20,pady=10)
        for f in files: box.insert('end',f.name)
        if not files: box.insert('end','No captures yet.')
    def show_music(self): self.simple_page('Music',['Music player','No external media engine required.','Select a local audio file to preview its filename and simulate playback.']); ttk.Button(self.body,text='Select audio',command=lambda:filedialog.askopenfilename()).pack(pady=8); ttk.Button(self.body,text='▶ Play simulator',style='Accent.TButton',command=lambda:messagebox.showinfo('Music','Playback started (simulator).')).pack()
    def show_recorder(self): self.simple_page('Recorder',['Voice Recorder','Native simulator for recording sessions.']); ttk.Button(self.body,text='● Start recording',style='Accent.TButton',command=lambda:messagebox.showinfo('Recorder','Recording started.')).pack(pady=10); ttk.Button(self.body,text='■ Stop').pack()
    def show_notes(self):
        self.clear_body(); self.make_app_header('Notes'); t=tk.Text(self.body,bg=T['input'],fg=T['fg'],insertbackground=T['fg'],wrap='word',borderwidth=0); t.pack(fill='both',expand=True,padx=18,pady=8); t.insert('1.0',state.get('notes',''))
        ttk.Button(self.body,text='Save note',style='Accent.TButton',command=lambda:[state.update(notes=t.get('1.0','end-1c')),save_data(),messagebox.showinfo('Notes','Saved locally.')]).pack(pady=8)
    def show_calendar(self): self.simple_page('Calendar',[time.strftime('%B %Y'), '', 'Today: '+time.strftime('%A, %B %d, %Y'),'Your schedule is stored locally in JamOS.']); ttk.Button(self.body,text='＋ Add event',command=lambda:messagebox.showinfo('Calendar','Event editor ready in the simulator.')).pack(pady=8)
    def show_clock(self):
        self.clear_body(); self.make_app_header('Clock'); lbl=tk.Label(self.body,bg=T['bg'],fg=T['fg'],font=('Segoe UI Semibold',46)); lbl.pack(pady=50); sub=tk.Label(self.body,bg=T['bg'],fg=T['muted'],font=('Segoe UI',12)); sub.pack();
        def tick(): lbl.config(text=time.strftime('%H:%M:%S')); sub.config(text=time.strftime('%A, %B %d, %Y')); lbl.after(500,tick)
        tick()
    def show_weather(self): self.simple_page('Weather',['Sunny · 72°F','Feels like 74°F','Wind 6 mph','JamOS weather is a local simulator and can later be connected to a weather service.'])
    def show_files(self):
        self.clear_body(); self.make_app_header('Files'); box=tk.Listbox(self.body,bg=T['input'],fg=T['fg'],selectbackground=T['accent'],borderwidth=0); box.pack(fill='both',expand=True,padx=20,pady=10)
        entries=sorted(BASE.iterdir(), key=lambda p:p.name.lower())
        for p in entries: box.insert('end',('▰ ' if p.is_dir() else '□ ')+p.name)
        ttk.Button(self.body,text='Open files folder',command=lambda:os.startfile(str(BASE))).pack(pady=6)
    def show_downloads(self): self.simple_page('Downloads',[*(p.name for p in sorted(DOWNLOADS.iterdir()) if p.is_file())] or ['No downloads.']);
    def show_terminal(self):
        self.clear_body(); self.make_app_header('Terminal'); out=tk.Text(self.body,bg='#090b0e',fg='#c9f6d5',insertbackground='#c9f6d5',font=('Consolas',10),borderwidth=0); out.pack(fill='both',expand=True,padx=16,pady=8); out.insert('end','JamOS Terminal 0.07\nType help, dir, version, clear, or exit.\n\n')
        ent=ttk.Entry(self.body); ent.pack(fill='x',padx=16,pady=(0,12));
        def run(event=None):
            cmd=ent.get().strip(); ent.delete(0,'end');
            if cmd=='help': out.insert('end','help  dir  version  clear  time\n')
            elif cmd=='version': out.insert('end',f'JamOS {APP_VERSION}\n')
            elif cmd=='dir': out.insert('end','\n'.join(p.name for p in BASE.iterdir())+'\n')
            elif cmd=='time': out.insert('end',time.ctime()+'\n')
            elif cmd=='clear': out.delete('1.0','end')
            elif cmd: out.insert('end',f'Unknown command: {cmd}\n')
            out.see('end')
        ent.bind('<Return>',run)
    def show_store(self):
        self.clear_body(); self.make_app_header('App Store')
        for app in ['Calculator','Mail','Maps','Weather','Recorder','Device Manager','Themes','Files Plus','Jam Player']:
            f=tk.Frame(self.body,bg=T['card']); f.pack(fill='x',padx=20,pady=4)
            tk.Label(f,text=app,bg=T['card'],fg=T['fg'],font=('Segoe UI Semibold',10)).pack(side='left',padx=12,pady=10)
            ttk.Button(f,text='Open',command=lambda a=app:messagebox.showinfo('App Store',a+' is included in this simulator.')).pack(side='right',padx=10)
    def show_maps(self): self.simple_page('Maps',['Maps simulator','Search places, save favorites, and open locations in the system browser.']); ttk.Button(self.body,text='Open map service',command=lambda:webbrowser.open('https://maps.google.com')).pack(pady=8)
    def show_mail(self): self.simple_page('Mail',['Inbox','No new messages.','Mail is currently local-only in this simulator.']); ttk.Button(self.body,text='Compose',command=lambda:messagebox.showinfo('Mail','Compose window opened.')).pack(pady=8)
    def show_wifi(self):
        self.clear_body(); self.make_app_header('Wi‑Fi'); var=tk.BooleanVar(value=state.get('wifi',True)); tk.Checkbutton(self.body,text='Wi‑Fi enabled',variable=var,bg=T['bg'],fg=T['fg'],selectcolor=T['card'],activebackground=T['bg'],command=lambda:[state.update(wifi=var.get()),save_data()]).pack(anchor='w',padx=25,pady=15)
        tk.Label(self.body,text='Available networks',bg=T['bg'],fg=T['muted']).pack(anchor='w',padx=25)
        for n in ['JamNet','Home‑5G','Guest Wi‑Fi']: ttk.Button(self.body,text=n,command=lambda x=n:messagebox.showinfo('Wi‑Fi',f'Connected to {x} (simulator).')).pack(fill='x',padx=25,pady=3)
    def show_device(self): self.simple_page('Device',['JamOS Virtual Device','Model: JamOS Simulator','Architecture: Windows host / Python','OS version: '+APP_VERSION,'Storage: local application directory'])
    def show_display(self):
        self.clear_body(); self.make_app_header('Display'); tk.Label(self.body,text='Brightness',bg=T['bg'],fg=T['fg']).pack(anchor='w',padx=20,pady=(18,5)); s=ttk.Scale(self.body,from_=10,to=100,orient='horizontal'); s.set(state.get('brightness',80)); s.pack(fill='x',padx=20); ttk.Button(self.body,text='Apply',command=lambda:[state.update(brightness=int(s.get())),save_data()]).pack(pady=10)
    def show_about(self): self.simple_page('About',['JamOS','A native Python/Tkinter phone simulator for Windows.','Version '+APP_VERSION,'OTA channel: GitHub /direct/','No webview UI. No third-party GUI framework.'])
    def show_settings(self):
        self.clear_body(); self.current='settings'; self.header('Settings','Personalize JamOS')
        for title,subtitle,cmd in [('Themes','Choose the system look',self.show_themes),('Display','Brightness and UI',self.show_display),('Wi‑Fi','Network simulator',self.show_wifi),('Device','System details',self.show_device),('Software Updates','Check GitHub OTA',self.show_updates),('About','JamOS information',self.show_about)]:
            f=tk.Frame(self.body,bg=T['card']); f.pack(fill='x',padx=18,pady=4); ttk.Button(f,text=title+'\n'+subtitle,command=cmd).pack(fill='x')
    def show_themes(self):
        self.clear_body(); self.header('Themes','Choose a native JamOS theme')
        for name in THEMES:
            f=tk.Frame(self.body,bg=T['card']); f.pack(fill='x',padx=20,pady=5)
            tk.Label(f,text=name,bg=T['card'],fg=T['fg'],font=('Segoe UI Semibold',11)).pack(side='left',padx=12,pady=12)
            ttk.Button(f,text='Use',command=lambda n=name:self.apply_theme(n)).pack(side='right',padx=10)
    def apply_theme(self,name): state['theme']=name; save_data(); self.destroy(); os.execl(sys.executable, sys.executable, *sys.argv)
    def show_updates(self):
        self.clear_body(); self.make_app_header('Software Updates'); status=tk.Label(self.body,text='Ready to check.',bg=T['bg'],fg=T['muted']); status.pack(pady=20); bar=ttk.Progressbar(self.body,length=340,mode='determinate'); bar.pack(pady=10)
        def check():
            status.config(text='Checking GitHub…');
            try:
                api='https://api.github.com/repos/Jamman101213/OTA-JamOS/contents/direct'
                req=urllib.request.Request(api,headers={'User-Agent':'JamOS/0.07'}); data=json.loads(urllib.request.urlopen(req,timeout=8).read().decode())
                versions=[]
                for x in data:
                    m=re.match(r'^(\d+(?:\.\d+)*)\.zip$',x.get('name',''))
                    if m: versions.append((tuple(map(int,m.group(1).split('.'))),x['name'],x.get('download_url')))
                if not versions:
                    status.config(text='No OTA ZIP releases found in direct/.'); return
                versions.sort(); installed=tuple(map(int,APP_VERSION.split('.'))); newer=[v for v in versions if v[0]>installed]
                if not newer: status.config(text=f'JamOS {APP_VERSION} is up to date.'); return
                latest=newer[-1]; status.config(text=f'JamOS {latest[1][:-4]} is available.');
                ttk.Button(self.body,text=f'Download JamOS {latest[1][:-4]}',style='Accent.TButton',command=lambda:download(latest[2],latest[1][:-4])).pack(pady=12)
            except Exception as ex: status.config(text=f'Update check failed: {ex}')
        def download(url,ver):
            status.config(text=f'Downloading JamOS {ver}…'); bar['value']=0
            target=DOWNLOADS/f'JamOS_{ver}.zip'
            def worker():
                try:
                    req=urllib.request.Request(url,headers={'User-Agent':'JamOS/0.07'}); r=urllib.request.urlopen(req,timeout=15); total=int(r.headers.get('Content-Length','0')); done=0
                    with target.open('wb') as f:
                        while True:
                            chunk=r.read(64*1024)
                            if not chunk: break
                            f.write(chunk); done+=len(chunk)
                            pct=int(done*100/total) if total else 0
                            self.after(0,lambda p=pct: bar.configure(value=p))
                    self.after(0,lambda:[status.config(text=f'JamOS {ver} downloaded. Ready to restart/apply.'),self.offer_apply(target,ver)])
                except Exception as ex: self.after(0,lambda:status.config(text=f'Download failed: {ex}'))
            threading.Thread(target=worker,daemon=True).start()
        ttk.Button(self.body,text='Check for updates',command=check).pack(pady=5)
    def offer_apply(self,target,ver):
        ttk.Button(self.body,text=f'Install JamOS {ver} & Restart',style='Accent.TButton',command=lambda:self.apply_ota(target,ver)).pack(pady=8)
    def apply_ota(self,target,ver):
        import zipfile, shutil
        try:
            z=zipfile.ZipFile(target); names=z.namelist();
            if 'setup.txt' not in names: raise ValueError('OTA package is missing setup.txt')
            manifest=z.read('setup.txt').decode('utf-8','replace'); files=[]
            for line in manifest.splitlines():
                if line.startswith('file='): files.append(line[5:].strip())
            stage=BASE.parent/('.jamos_stage_'+ver); shutil.rmtree(stage,ignore_errors=True); stage.mkdir()
            z.extractall(stage); z.close()
            helper=BASE/'updater.pyw'
            subprocess.Popen([sys.executable,str(helper),str(stage),str(BASE)],close_fds=True)
            self.destroy()
        except Exception as ex: messagebox.showerror('Update error',str(ex))
    def toggle_notifications(self):
        w=tk.Toplevel(self); w.title('Notifications'); w.geometry('340x430'); w.resizable(False,False); w.configure(bg=T['panel'])
        tk.Label(w,text='Notifications',bg=T['panel'],fg=T['fg'],font=('Segoe UI Semibold',18)).pack(anchor='w',padx=18,pady=16)
        if not self.notifications: tk.Label(w,text='No new notifications',bg=T['panel'],fg=T['muted']).pack(pady=25)
        for title,body in self.notifications[-8:]:
            f=tk.Frame(w,bg=T['card']); f.pack(fill='x',padx=12,pady=4); tk.Label(f,text=title,bg=T['card'],fg=T['fg'],font=('Segoe UI Semibold',10)).pack(anchor='w',padx=10,pady=(8,0)); tk.Label(f,text=body,bg=T['card'],fg=T['muted'],wraplength=290,justify='left').pack(anchor='w',padx=10,pady=(0,8))
    def demo_notification(self):
        self.notifications.append(('JamOS 0.07','Native phone simulator is ready.')); 
    def clock_tick(self):
        if self.winfo_exists():
            self.time_lbl.config(text=time.strftime('%H:%M'))
            self.after(1000,self.clock_tick)

if __name__=='__main__':
    JamOS().mainloop()
