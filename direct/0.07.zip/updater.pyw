import sys, time, shutil, zipfile, subprocess, os
from pathlib import Path

def read_manifest(stage):
    p=stage/'setup.txt'; manifest=p.read_text(encoding='utf-8') if p.exists() else ''
    files=[]
    for line in manifest.splitlines():
        line=line.strip()
        if line.startswith('file='):
            f=line[5:].strip().replace('\\','/')
            if f and not f.endswith('.gitkeep'): files.append(f)
    return files

def read_previous_manifest(base):
    p=base/'system'/'installed_manifest.txt'
    if not p.exists(): return []
    return [x.strip() for x in p.read_text(encoding='utf-8').splitlines() if x.strip() and not x.strip().endswith('.gitkeep')]

if __name__=='__main__':
    stage=Path(sys.argv[1]); base=Path(sys.argv[2]); files=read_manifest(stage)
    time.sleep(1.5)
    try:
        previous=read_previous_manifest(base)
        for f in previous:
            if f not in files:
                old=base/f
                if old.is_file(): old.unlink()
        for f in files:
            src=stage/f; dst=base/f; dst.parent.mkdir(parents=True,exist_ok=True)
            if src.exists() and src.is_file(): shutil.copy2(src,dst)
        for f in files: (base/f).parent.mkdir(parents=True,exist_ok=True)
        (base/'system'/'installed_manifest.txt').write_text('\n'.join(files)+'\n',encoding='utf-8')
        sd=stage/'setup.txt'
        if sd.exists(): sd.unlink()
        shutil.rmtree(stage,ignore_errors=True)
        subprocess.Popen([sys.executable,str(base/'main.py')],cwd=str(base),close_fds=True)
    except Exception as e:
        (base/'system'/'update_error.txt').write_text(str(e),encoding='utf-8')
        subprocess.Popen([sys.executable,str(base/'main.py')],cwd=str(base),close_fds=True)
