import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

import webview

APP_ROOT = Path(__file__).resolve().parent
WEB_ROOT = APP_ROOT / "web"
USERDATA_PATH = APP_ROOT / "userdata" / "userdata.json"
OTA_ROOT = APP_ROOT / "ota"
STAGING = OTA_ROOT / "staging"
BACKUPS = OTA_ROOT / "backups"
REPO_OWNER = "Jamman101213"
REPO_NAME = "OTA-JamOS"
DIRECT_PATH = "direct"
GITHUB_CONTENTS = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{DIRECT_PATH}"
USER_AGENT = "JamOS-OTA/0.02"


def load_userdata():
    with USERDATA_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def atomic_write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")
    tmp.replace(path)


def version_key(version_text: str):
    # Supports: 0.01 Beta, 0.1, 1.1, 2.0.0
    nums = re.findall(r"\d+", str(version_text))
    if not nums:
        return (0, 0, 0)
    vals = [int(x) for x in nums[:3]]
    vals += [0] * (3 - len(vals))
    return tuple(vals)


def version_label_from_name(name: str):
    stem = Path(name).stem
    m = re.search(r"\d+(?:\.\d+){0,3}", stem)
    return m.group(0) if m else stem


def http_get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode("utf-8"))


def http_download(url, dest: Path, progress_cb=None):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=60) as r:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        with dest.open("wb") as f:
            while True:
                chunk = r.read(64 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if progress_cb:
                    progress_cb(done, total)


def safe_relpath(p):
    p = Path(p)
    if p.is_absolute() or ".." in p.parts:
        raise ValueError(f"Unsafe path in OTA package: {p}")
    return p


class JamOSAPI:
    def __init__(self):
        self.window = None
        self.state = {"checking": False, "available": False, "error": None, "update": None}

    def _send(self, event, payload=None):
        if not self.window:
            return
        message = json.dumps({"event": event, "payload": payload})
        script = f"window.jamosEvent({json.dumps(message)})"
        try:
            self.window.evaluate_js(script)
        except Exception:
            pass

    def get_userdata(self):
        return load_userdata()

    def check_for_ota(self):
        if self.state["checking"]:
            return {"ok": False, "message": "Already checking."}

        self.state["checking"] = True
        self.state["error"] = None
        self._send("ota_status", {"status": "checking", "message": "Checking GitHub for updates…"})

        def worker():
            try:
                current = load_userdata().get("version", "0.02")
                entries = http_get_json(GITHUB_CONTENTS)
                candidates = []
                for item in entries if isinstance(entries, list) else []:
                    name = item.get("name", "")
                    lower = name.lower()
                    if item.get("type") == "file" and lower.endswith(".zip"):
                        label = version_label_from_name(name)
                        if re.search(r"\d", label):
                            candidates.append({"version": label, "name": name, "type": "zip", "download": item.get("download_url")})
                    elif item.get("type") == "dir" and re.search(r"\d", name):
                        candidates.append({"version": version_label_from_name(name), "name": name, "type": "dir", "url": item.get("url")})

                candidates.sort(key=lambda x: version_key(x["version"]), reverse=True)
                newest = candidates[0] if candidates else None
                current_key = version_key(current)
                available = bool(newest and version_key(newest["version"]) > current_key)
                self.state.update({"available": available, "update": newest})
                if available:
                    msg = f"Update {newest['version']} is ready."
                elif newest:
                    msg = "You are up to date."
                else:
                    msg = "No OTA packages found in direct/."
                self._send("ota_result", {"available": available, "message": msg, "current": current, "newest": newest})
            except Exception as e:
                self.state["error"] = str(e)
                self._send("ota_error", {"message": str(e)})
            finally:
                self.state["checking"] = False

        threading.Thread(target=worker, daemon=True).start()
        return {"ok": True}

    def download_update(self):
        update = self.state.get("update")
        if not update or not self.state.get("available"):
            return {"ok": False, "message": "No update is available."}

        def worker():
            try:
                STAGING.mkdir(parents=True, exist_ok=True)
                for old in STAGING.iterdir():
                    if old.is_file() or old.is_symlink():
                        old.unlink()
                    elif old.is_dir():
                        shutil.rmtree(old)

                if update["type"] == "zip":
                    archive = STAGING / "ota_package.zip"
                    self._send("ota_status", {"status": "downloading", "message": "Downloading update…", "progress": 0})
                    http_download(update["download"], archive, lambda d, t: self._progress(d, t))
                    package_dir = STAGING / "package"
                    package_dir.mkdir()
                    with zipfile.ZipFile(archive, "r") as zf:
                        zf.extractall(package_dir)
                else:
                    package_dir = STAGING / "package"
                    package_dir.mkdir()
                    self._send("ota_status", {"status": "downloading", "message": "Downloading update files…", "progress": 0})
                    self._download_directory(update["url"], package_dir)

                # Allow either files directly in the package or a single version root folder.
                setup_files = list(package_dir.rglob("setup.txt"))
                if not setup_files:
                    raise ValueError("OTA package is missing setup.txt")
                setup_path = setup_files[0]
                root = setup_path.parent

                setup = self._read_setup(setup_path)
                if "version" not in setup:
                    raise ValueError("setup.txt must contain a version=	11.2	22 line")
                if version_key(setup["version"]) <= version_key(load_userdata().get("version", "0.02")):
                    raise ValueError("Downloaded package is not newer than the installed version.")

                # Stage is complete. Nothing is applied until Restart.
                manifest = {"root": str(root), "setup": setup, "prepared": True}
                atomic_write_json(STAGING / "pending.json", manifest)
                self._send("ota_ready", {"version": setup["version"], "message": "Download complete. Restart to apply update."})
            except Exception as e:
                self._send("ota_error", {"message": str(e)})

        threading.Thread(target=worker, daemon=True).start()
        return {"ok": True}

    def _progress(self, done, total):
        pct = int(done * 100 / total) if total else 0
        self._send("ota_progress", {"progress": pct})

    def _download_directory(self, api_url, out_root):
        items = http_get_json(api_url)
        files = [x for x in items if x.get("type") == "file"]
        dirs = [x for x in items if x.get("type") == "dir"]
        total_count = max(1, len(files))
        complete = 0
        for item in files:
            target = safe_relpath(item["name"])
            dest = out_root / target
            dest.parent.mkdir(parents=True, exist_ok=True)
            http_download(item["download_url"], dest)
            complete += 1
            self._send("ota_progress", {"progress": int(complete * 100 / total_count)})
        for d in dirs:
            self._download_directory(d["url"], out_root / safe_relpath(d["name"]))

    def _read_setup(self, path: Path):
        data = {"files": []}
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.lower().startswith("version="):
                data["version"] = line.split("=", 1)[1].strip()
            elif line.lower().startswith("userdata_version="):
                data["userdata_version"] = line.split("=", 1)[1].strip()
            elif line.lower().startswith("file="):
                data["files"].append(line.split("=", 1)[1].strip())
        return data

    def has_pending_update(self):
        p = STAGING / "pending.json"
        return p.exists()

    def restart(self):
        pending = STAGING / "pending.json"
        if not pending.exists():
            self._restart_process()
            return {"ok": True}

        try:
            manifest = json.loads(pending.read_text(encoding="utf-8"))
            root = Path(manifest["root"]).resolve()
            setup = manifest["setup"]
            listed = [safe_relpath(x) for x in setup.get("files", [])]
            if not listed:
                # Fall back to every file under the staged package, excluding setup metadata.
                listed = [p.relative_to(root) for p in root.rglob("*") if p.is_file() and p.name != "setup.txt"]

            backup = BACKUPS / time.strftime("%Y%m%d_%H%M%S")
            backup.mkdir(parents=True, exist_ok=True)

            # Remove any installed file not present in the new manifest.
            keep = {str(p).replace("\\", "/") for p in listed}
            for existing in APP_ROOT.rglob("*"):
                if not existing.is_file():
                    continue
                rel = existing.relative_to(APP_ROOT)
                if str(rel).replace("\\", "/") in {"ota/staging/pending.json"}:
                    continue
                rel_s = str(rel).replace("\\", "/")
                protected = rel_s.startswith("ota/") or rel_s == "userdata/userdata.json"
                if protected:
                    continue
                if rel_s not in keep and rel_s != "setup.txt":
                    dest = backup / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(existing), str(dest))

            # Copy/update every manifest file. Hardcoded destination = relative path in setup.txt.
            for rel in listed:
                src = root / rel
                if not src.exists() or not src.is_file():
                    raise ValueError(f"Manifest file is missing from package: {rel}")
                dest = APP_ROOT / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                if dest.exists():
                    b = backup / rel
                    b.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dest, b)
                shutil.copy2(src, dest)

            # Update version in userdata.json. Keep any user data fields intact.
            ud = load_userdata()
            ud["version"] = setup["userdata_version"] if setup.get("userdata_version") else setup["version"]
            ud["last_update"] = time.strftime("%Y-%m-%d %H:%M:%S")
            atomic_write_json(USERDATA_PATH, ud)

            # setup.txt is metadata only; remove it after the update has finished.
            package_setup = root / "setup.txt"
            if package_setup.exists():
                package_setup.unlink()
            if pending.exists():
                pending.unlink()
            shutil.rmtree(STAGING / "package", ignore_errors=True)
            archive = STAGING / "ota_package.zip"
            if archive.exists():
                archive.unlink()

            self._send("ota_status", {"status": "applied", "message": "Update applied. Restarting…"})
            self._restart_process()
            return {"ok": True}
        except Exception as e:
            self._send("ota_error", {"message": f"Update failed: {e}"})
            return {"ok": False, "message": str(e)}

    def _restart_process(self):
        if self.window:
            try:
                self.window.hide()
            except Exception:
                pass
        time.sleep(0.3)
        args = [sys.executable, str(Path(__file__).resolve())]
        subprocess.Popen(args, cwd=str(APP_ROOT), close_fds=(os.name != "nt"))
        try:
            self.window.destroy()
        except Exception:
            os._exit(0)


if __name__ == "__main__":
    api = JamOSAPI()
    window = webview.create_window(
        "JamOS 0.02",
        str((WEB_ROOT / "index.html").as_uri()),
        width=360,
        height=760,
        resizable=False,
        fullscreen=False,
        easy_drag=False,
        js_api=api,
    )
    api.window = window
    webview.start(debug=False)
